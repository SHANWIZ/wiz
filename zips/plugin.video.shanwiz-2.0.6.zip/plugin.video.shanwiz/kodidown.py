#!/usr/bin/python

import subprocess
import platform,os

subprocess.call(['pkill','-9','Kodi'])
#subprocess.call(['open','-a','Kodi'])
os.system('pkill -9 Kodi && open -a Kodi')
